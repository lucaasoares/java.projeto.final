package com.projeto.biblioteca.controller;

import com.projeto.biblioteca.dto.*;
import com.projeto.biblioteca.model.Usuario;
import com.projeto.biblioteca.repository.UsuarioRepository;
import com.projeto.biblioteca.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/cliente")
public class ClienteController {

    private final ClienteService clienteService;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public ClienteController(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @GetMapping("/livros")
    public RespostaDTO listarLivrosDisponiveis() {
        return new RespostaDTO(
                "Catálogo de livros disponíveis",
                clienteService.listarLivrosDisponiveis()
        );
    }

    @PostMapping("/alugar")
    public RespostaDTO alugarLivro(@RequestBody EmprestimoDTO emprestimoDTO) {
        return new RespostaDTO(
                "Livro alugado com sucesso!",
                clienteService.alugarLivro(emprestimoDTO.getLivroId(), emprestimoDTO.getUsuarioId())
        );
    }

    @PostMapping("/devolver")
    public RespostaDTO devolverLivro(@RequestBody EmprestimoDTO emprestimoDTO) {
        return new RespostaDTO(
                "Livro devolvido!",
                clienteService.devolverLivro(emprestimoDTO.getLivroId(), emprestimoDTO.getUsuarioId())
        );
    }

    // NOVO ENDPOINT - Atualização de perfil do usuário
    @PutMapping("/usuarios/{id}")
    public ResponseEntity<?> atualizarPerfil(
            @PathVariable Long id,
            @RequestBody UsuarioDTO usuarioDTO) {

        Optional<Usuario> usuarioOptional = usuarioRepository.findById(id);
        if (!usuarioOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuário não encontrado");
        }

        Usuario usuario = usuarioOptional.get();
        usuario.setNome(usuarioDTO.getNome());
        usuario.setEmail(usuarioDTO.getEmail());

        if (usuarioDTO.getSenha() != null && !usuarioDTO.getSenha().isBlank()) {
            usuario.setSenha(passwordEncoder.encode(usuarioDTO.getSenha()));
        }

        usuarioRepository.save(usuario);
        return ResponseEntity.ok("Perfil atualizado com sucesso!");


    }

    // NOVO ENDPOINT - Buscar dados do usuário por ID
    @GetMapping("/usuarios/{id}")
    public ResponseEntity<?> buscarUsuarioPorId(@PathVariable Long id) {
        Optional<Usuario> usuarioOptional = usuarioRepository.findById(id);
        if (usuarioOptional.isPresent()) {
            Usuario usuario = usuarioOptional.get();
            UsuarioDTO dto = new UsuarioDTO();
            dto.setNome(usuario.getNome());
            dto.setEmail(usuario.getEmail());
            return ResponseEntity.ok(dto);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuário não encontrado");
        }
    }
}
